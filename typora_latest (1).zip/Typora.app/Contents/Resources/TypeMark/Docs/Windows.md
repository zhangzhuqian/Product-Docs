# TODO:

1. http://www.shortcutworld.com/en/win/Word_2010.html#link_9
2. ctrl+F6

